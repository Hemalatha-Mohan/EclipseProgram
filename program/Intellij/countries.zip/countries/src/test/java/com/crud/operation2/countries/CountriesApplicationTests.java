package com.crud.operation2.countries;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class CountriesApplicationTests {

	@Test
	void contextLoads() {
	}

}
